import re, os, urllib.request
BASE='https://raw.githubusercontent.com/DivinumOfficium/divinum-officium/master/web/www/horas/'
def fetch(lang, path):
    p=f'/home/claude/do_cache/{lang}_{path.replace("/","_")}.txt'
    if not os.path.exists(p):
        try: d=urllib.request.urlopen(BASE+f'{lang}/{path}.txt',timeout=30).read().decode('utf-8')
        except Exception: d=''
        open(p,'w').write(d)
    return open(p).read()
def raw_section(txt, name):
    best=None
    for m in re.finditer(r'^\['+re.escape(name)+r'\][ \t]*(\([^)\n]*\))?[^\n]*\n(.*?)(?=^\[|\Z)',txt,re.M|re.S):
        cond=(m.group(1) or '').lower()
        ok = (not cond) or ('nisi' in cond and 'divino' not in cond.split('nisi')[1]) or ('divino' in cond.split('nisi')[0])
        if not ok: continue
        body=m.group(2)
        out=[]
        for l in body.rstrip('\n').split('\n'):
            if re.match(r'^\((sed|deinde|atque)\b',l): break
            out.append(l)
        sec='\n'.join(out).strip()
        if 'divino' in cond: return sec
        if best is None: best=sec
    return best
def resolve(lang, path, name, depth=0):
    """path like 'Sancti/01-05' or 'Tempora/Nat1-0' or 'Commune/C9'"""
    if depth>6: return None
    t=fetch(lang,path)
    s=raw_section(t,name)
    if s is None: return None
    m=re.match(r'^@([^:\n]*)(?::([^:\n]*))?(?::(.*))?$', s.split('\n')[0].strip())
    if m:
        p2=m.group(1) or path; n2=m.group(2) or name; mod=m.group(3)
        r=resolve(lang,p2,n2,depth+1)
        if r is None: return None
        if mod:
            m2=re.match(r'^(\d+)-(\d+)$',mod)
            if m2:
                L=r.split('\n'); r='\n'.join(L[int(m2.group(1))-1:int(m2.group(2))])
            else:
                for sm in re.finditer(r's/((?:[^/\\]|\\.)*)/((?:[^/\\]|\\.)*)/(g?)',mod):
                    r=re.sub(sm.group(1),sm.group(2).replace('$','\\'),r,count=0 if sm.group(3) else 1)
        rest='\n'.join(s.split('\n')[1:]).strip()
        return r+('\n'+rest if rest else '')
    return s

def resolve2(lang, path, name, depth=0):
    """DO-style: use lang file's section if present; else follow the Latin file's reference into lang."""
    if depth>6: return None
    t=fetch(lang,path); s=raw_section(t,name)
    if s is None and lang!='Latin':
        s=raw_section(fetch('Latin',path),name)
        if s is None or not s.startswith('@'): return None
    if s is None: return None
    m=re.match(r'^@([^:\n]*)(?::([^:\n]*))?(?::(.*))?$', s.split('\n')[0].strip())
    if not m: return s
    p2=m.group(1) or path; n2=m.group(2) or name; mod=m.group(3)
    r=resolve2(lang,p2,n2,depth+1)
    if r is None: return None
    if mod:
        m2=re.match(r'^(\d+)-(\d+)$',mod)
        if m2:
            L=r.split('\n'); r='\n'.join(L[int(m2.group(1))-1:int(m2.group(2))])
        else:
            for sm in re.finditer(r's/((?:[^/\\]|\\.)*)/((?:[^/\\]|\\.)*)/(g?)',mod):
                pat=sm.group(1)
                if lang=='English': pat=pat.replace('allelúja','alleluia')
                r=re.sub(pat,sm.group(2),r,count=0 if sm.group(3) else 1, flags=re.I)
    rest='\n'.join(s.split('\n')[1:]).strip()
    return r+('\n'+rest if rest else '')
