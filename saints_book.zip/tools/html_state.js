/* ---------- state & rendering ---------- */
let state={date:new Date(),hour:'lauds'};
function currentHourKey(){const h=new Date().getHours();let k='matins';HOURS.forEach(x=>{if(h>=x.from)k=x.k});return k}
function esc(s){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
function para(s){return s.split(/\n\n/).map(p=>'<p>'+esc(p).replace(/\n/g,'<br>')+'</p>').join('')}
function frame(item,open){
  return `<details class="frame"${open?' open':''}><summary>${esc(item.title)}</summary><div class="framebody"><div class="la">${decorate(para(item.latin))}</div><div class="en">${decorate(para(item.english))}</div></div></details>`;
}
function renderRibbons(){
  const R=$('#ribbons'); R.innerHTML=AV.map(h=>`<button class="rib" data-h="${h.k}" aria-current="${h.k===state.hour}" title="${h.la}">${h.en}</button>`).join('');
  const a=R.querySelector('[aria-current="true"]'); if(a) a.scrollIntoView({block:'nearest',inline:'center'});
}
let PASCH=false;
const KIND={office:'Office',simplex:'Office (simplex)',commem:'Commemoration only',local:'Local feast'};
async function render(push=true){
  const e=rec(); let day=await loadDay(); if(day.missing) day=null;
  const [mm,dd]=e.date.split('-').map(Number);
  $('#civil').textContent=MONTHS_EN[mm-1]+' '+dd; $('#datePick').value=new Date().getFullYear()+'-'+e.date;
  $('#feastPick').value=e.id;
  $('#vol').textContent='';
  const HRS = day ? ((PASCH && day.hours_pasch) ? day.hours_pasch : day.hours) : {};
  $('#info').innerHTML=`<b>${esc(e.rank)}</b> · ${esc(KIND[e.kind]||'')}${day&&day.common?' · '+esc(PASCH&&day.hours_pasch?day.common_pasch:day.common_name):''}`+
    (day&&day.hours_pasch?` · <button id="paschBtn" style="font:inherit;font-size:.82rem;padding:1px 8px;border:1px solid var(--line);border-radius:4px;background:${PASCH?'var(--gold)':'none'};color:${PASCH?'var(--parchment)':'var(--ink-soft)'}">${PASCH?'Paschaltide texts shown':'Show Paschaltide texts'}</button>`:'');
  AV = day ? HOURS.filter(h=>HRS[h.k]) : [];
  if(day && !AV.some(h=>h.k===state.hour)) state.hour=(AV.find(h=>h.k==='lauds')||AV[0]).k;
  renderRibbons();
  if(!day){
    $('#enTitle').textContent=e.en; $('#laTitle').textContent=e.la||'';
    $('#main').innerHTML=`<div class="missing"><p>${e.kind==='local'?'This local feast is in the 1954 calendar, but its texts are not in the data yet.':'Not available.'}</p></div>`;
  } else {
    $('#enTitle').textContent=day.en; $('#laTitle').textContent=day.la;
    const H=AV.find(h=>h.k===state.hour), i=AV.indexOf(H);
    let body=HRS[H.k];
    $('#main').innerHTML=`<div class="hourhead"><h2>${H.la} · ${H.en}</h2><div class="sub solo-sub">${esc(day.en)}</div></div>`+
      frame(ANTE[0],store.get('anteOpen',false))+`<div class="text">${decorate(body)}</div>`+frame(ANTE[1],false)+
      `<nav class="hournav"><button data-step="-1" ${i===0?'disabled':''}>‹ ${i>0?AV[i-1].en:''}</button><button data-step="1" ${i===AV.length-1?'disabled':''}>${i<AV.length-1?AV[i+1].en:''} ›</button></nav>`;
    document.title=`${H.en} — ${day.en}`;
  }
  document.body.classList.toggle('solo',!!state.solo);
  const base='#'+e.id+'/'+state.hour, hash=base+(state.solo?'/solo':''); if(push&&location.hash!==hash) history.replaceState(null,'',hash);
  const fl=$('#focusLink'); if(fl){fl.href=state.solo?base:base+'/solo'; fl.textContent=state.solo?'‹ Full book':'Open this hour alone';}
  store.set('saints.last',{id:e.id,hour:state.hour});
}
function feastFor(date){ const md=String(date.getMonth()+1).padStart(2,'0')+'-'+String(date.getDate()).padStart(2,'0');
  const f=INDEX.find(x=>x.date===md && x.kind!=='local') || INDEX.find(x=>x.date>=md) || INDEX[0]; return f.id; }
function go(date,hour,scroll=true){ if(date) CUR=feastFor(date); state.hour=hour||state.hour; render(); if(scroll)window.scrollTo({top:0}); }
function stepFeast(n){ const i=INDEX.findIndex(x=>x.id===CUR); const j=Math.min(INDEX.length-1,Math.max(0,i+n)); CUR=INDEX[j].id; render(); window.scrollTo({top:0}); }

