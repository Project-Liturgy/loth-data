"""Office of the Dead for All Souls (1954, Divino Afflatu): Vespers, Matins, Lauds."""
import re, json, html
exec(open('/home/claude/doref.py').read())
E = lambda s: html.escape(s, quote=False)
C9 = 'Commune/C9'
PR = 'Psalterium/Common/Prayers'
S = json.load(open('/home/claude/loth-data/saints_texts.json'))
FILL = json.load(open('/home/claude/loth-data/english_fill.json'))
AS = S['11-02|All Souls']['sections']

def sec(name, path=C9):
    return resolve2('Latin', path, name) or '', resolve2('English', path, name) or ''

def pair(la, en, cls=''):
    return f'<div class="pair{(" " + cls) if cls else ""}"><div class="la">{la}</div><div class="en">{en}</div></div>\n'
def head(la, en): return pair(f'<h3>{la}</h3>', f'<h3>{en}</h3>')
def rub(t): return f'<p class="rub" style="text-align:center;margin:10px 0">{E(t)}</p>\n'
def vline(t):
    t = re.sub(r'^V\.\s*', '℣. ', t); t = re.sub(r'^R\.\s*', '℟. ', t); t = re.sub(r'^[vr]\.\s*', '', t)
    return E(t)
def vr(la, en):  # versicle/response lines, one pair per line
    L, M = [x for x in la.split('\n') if x.strip()], [x for x in en.split('\n') if x.strip()]
    return ''.join(pair(f'<p class="versicle">{vline(a)}</p>', f'<p class="versicle">{vline(b)}</p>') for a, b in zip(L, M))
def ant(la, en, first=True):
    la = re.sub(r';;.*$', '', la); en = re.sub(r';;.*$', '', en)
    if not first: la, en = la.replace(' * ', ' ').replace('* ', ''), en.replace(' * ', ' ').replace('* ', '')
    return pair(f'<p><span class="tag">Ant.</span> {E(la)}</p>', f'<p><span class="tag">Ant.</span> {E(en)}</p>', 'ant')

REQ = sec('Requiem', PR)
def requiem():
    return ''.join(pair(f'<ul class="verses"><li>{vline(a)}</li></ul>', f'<ul class="verses"><li>{vline(b)}</li></ul>')
                   for a, b in zip(REQ[0].split('\n'), REQ[1].split('\n')))

PS_TITLE = {222: ('Canticum Ezechiæ', 'Canticle of Ezechias'), 231: ('Canticum Zachariæ', 'Canticle of Zachary'),
            232: ('Canticum B. Mariæ Virginis', 'Canticle of the Blessed Virgin Mary')}
def verse(t):
    t = t.replace(' + ', ' ✠ ').replace('+ ', '✠ ')
    t = re.sub(r'^(\d+:\d+)[a-z]?\s', r'\1 ', t)
    return E(t)
def psalm(n):
    la = [l for l in fetch('Latin', f'Psalterium/Psalmorum/Psalm{n}').split('\n') if l.strip()]
    en = [l for l in fetch('English', f'Psalterium/Psalmorum/Psalm{n}').split('\n') if l.strip()]
    cite = ''
    if la and la[0].startswith('('):
        m = re.search(r'\*\s*([^)]*)\)', la[0]); cite = m.group(1).strip() if m else ''
        la = la[1:]; en = en[1:] if en and en[0].startswith('(') else en
    tl = PS_TITLE.get(n, (f'Psalmus {n}',))[0]; te = tl
    out = head(tl, te)
    if cite: out += pair(f'<ul class="verses"><li>{E(cite)}</li></ul>', f'<ul class="verses"><li>{E(cite)}</li></ul>')
    if len(la) != len(en): print('WARN verse count', n, len(la), len(en))
    for a, b in zip(la, en):
        out += pair(f'<ul class="verses"><li>{verse(a)}</li></ul>', f'<ul class="verses"><li>{verse(b)}</li></ul>')
    return out + requiem()

def psalmody(name):
    la, en = sec(name)
    L, M = [x for x in la.split('\n') if x.strip()], [x for x in en.split('\n') if x.strip()]
    out = ''
    for a, b in zip(L, M):
        n = int(re.search(r';;(\d+)', a).group(1))
        out += ant(a, b) + psalm(n) + ant(a, b, first=False)
    return out

def invitatory():
    la_a, en_a = sec('Invit')
    a2l = la_a.split('*', 1)[1].strip(); a2e = en_a.split('*', 1)[1].strip()
    out = head('Invitatorium', 'Invitatory') + head('Psalmus 94', 'Psalmus 94')
    L = [l for l in fetch('Latin', 'Psalterium/Invitatorium').split('\n') if l.strip()]
    M = [l for l in fetch('English', 'Psalterium/Invitatorium').split('\n') if l.strip()]
    clean = lambda t: E(re.sub(r'\s*[=^_]\s*', ' ', re.sub(r'^v\.\s*', '', t)).replace(' + ', ' ').replace('/:(genuflectitur):/', '(Here all kneel.)').replace('/:(kneel):/', '(Here all kneel.)'))
    for a, b in zip(L, M):
        if a.startswith('$ant2'): out += ant(a2l, a2e, False)
        elif a.startswith('$ant'): out += ant(la_a, en_a)
        elif a.startswith('&Gloria'): out += requiem()
        elif a.startswith('v.'): out += pair(f'<p>{clean(a)}</p>', f'<p>{clean(b)}</p>')
    return out

ROM = ['', 'i', 'ii', 'iii', 'iv', 'v', 'vi', 'vii', 'viii', 'ix']
def lines(t):
    out = []
    for l in t.split('\n'):
        l = l.rstrip()
        if not l.strip() or l.strip() == '_': continue
        if l.startswith('!'): out.append(f'<span class="rub">{E(l[1:].strip())}</span>'); continue
        l = re.sub(r'^\*\s*', '', l)
        m = re.match(r'^(\d+)\s(.*)$', l)
        if m: out.append(f'<span class="rub">{m.group(1)}</span> {E(m.group(2))}'); continue
        out.append(vline(l))
    return out
def block(la, en):
    L, M = lines(la), lines(en)
    if len(L) == len(M): return ''.join(pair(f'<p>{a}</p>', f'<p>{b}</p>') for a, b in zip(L, M))
    return pair(''.join(f'<p>{a}</p>' for a in L), ''.join(f'<p>{b}</p>' for b in M))
REQ_RESP = ('V. ' + REQ[0].replace('V. ', '').replace('\nR. ', ' ').replace(' * ', ' ').replace('Dómine.', 'Dómine:').replace(' lúceat', ' lúceat'),
            'V. ' + REQ[1].replace('V. ', '').replace(' \nR. ', ' ').replace('\nR. ', ' ').replace(' * ', ' ').replace('Lord.', 'Lord:'))
REQ_RESP = (REQ_RESP[0].replace(': Et', ': et'), REQ_RESP[1].replace(': And', ': and'))
def responsory(n):
    name = 'Responsory9' if n == 9 else f'Responsory{n}'
    la, en = sec(name)
    la = la.replace('$Requiem', REQ_RESP[0]); en = en.replace('$Requiem', REQ_RESP[1])
    return head(f'Responsorium {ROM[n]}', f'Responsory {n}') + block(la, en)
def lesson(n):
    x = AS[f'Lectio{n}']
    return head(f'Lectio {ROM[n]}', f'Lesson {n}') + block(x['la'], x['en'])

def prayers(hour):
    """concluding prayers of the Office of the Dead, as on All Souls"""
    out = rub('All kneel.')
    pl, pe = sec('Pater noster Et', PR)
    pl = pl.split('\n'); pe = pe.split('\n')
    out += pair('<p class="rub">Pater noster, secreto usque ad Et ne nos indúcas in tentatiónem:</p>',
                '<p class="rub">Our Father is said silently until And lead us not into temptation:</p>')
    out += vr('\n'.join(pl[1:]), '\n'.join(pe[1:]))
    out += rub(f'On All Souls the psalm {"Lauda, anima mea (Ps. 145)" if hour == "vespers" else "De profundis (Ps. 129)"} is omitted here.')
    for n in ('Aportainferi', 'Requiescant'):
        out += vr(*sec(n, PR))
    dl, de = sec('Dominus', PR)
    out += vr('\n'.join(dl.split('\n')[2:4]), '\n'.join(de.split('\n')[2:4]))
    ol, oe = sec('Oremus', PR)
    fl = resolve2('Latin', C9, 'Oratio_Fid').split('\n'); 
    fid_la = [l for l in fl if l.startswith('v. ')][0][3:]
    fid_en = FILL['Commune/C9|Oratio']['text'].split('\n')[0]
    ql, qe = sec('Qui vivis', PR)
    out += head('Oratio', 'Collect')
    out += pair(f'<p>{vline(ol)}</p>', f'<p>{vline(oe)}</p>')
    out += pair(f'<p>{E(fid_la)}</p>', f'<p>{E(fid_en)}</p>')
    out += vr(ql, qe)
    rl = '\n'.join(REQ[0].replace(' * ', ' ').split('\n')); re_ = '\n'.join(REQ[1].replace(' * ', ' ').split('\n'))
    out += vr(rl, re_) + vr(*sec('Requiescant', PR))
    return out

def vespers():
    out = rub('The Office of the Dead begins at once with the first antiphon (no Deus in adjutórium, hymn, or chapter).')
    out += head('Antiphonæ et Psalmi', 'Antiphons and Psalms') + psalmody('Ant Vespera')
    out += head('Versus', 'Versicle') + vr(*sec('Versum 1'))
    al, ae = sec('Ant 1')
    out += head('Ad Magnificat', 'At the Magnificat') + ant(al, ae) + psalm(232) + ant(al, ae, False)
    return out + prayers('vespers')

def matins():
    out = rub('Matins begins at once with the Invitatory. There is no hymn.') + invitatory()
    la, en = sec('Ant Matutinum')
    A = list(zip([x for x in la.split('\n') if x.strip()], [x for x in en.split('\n') if x.strip()]))
    for n in (1, 2, 3):
        out += head(f'In {"I" * n if n < 3 else "III"} Nocturno', f'Nocturn {"I" * n if n < 3 else "III"}')
        for a, b in A[3 * n - 3: 3 * n]:
            p = int(re.search(r';;(\d+)', a).group(1))
            out += ant(a, b) + psalm(p) + ant(a, b, False)
        out += vr(*sec(f'Nocturn {n} Versum'))
        out += rub('Pater noster, said silently. No absolution or blessings are said, and the lessons end without Tu autem.')
        for i in range(3 * n - 2, 3 * n + 1):
            out += lesson(i) + responsory(i)
    out += rub('Te Deum is not said.')
    out += rub('If Lauds does not follow at once, the prayers are said as at the end of Lauds.')
    return out

def lauds():
    out = rub('Lauds begins at once with the first antiphon.')
    out += head('Antiphonæ et Psalmi', 'Antiphons and Psalms') + psalmody('Ant Laudes')
    out += head('Versus', 'Versicle') + vr(*sec('Versum 2'))
    al, ae = sec('Ant 2')
    out += head('Ad Benedictus', 'At the Benedictus') + ant(al, ae) + psalm(231) + ant(al, ae, False)
    return out + prayers('lauds')

def build():
    return {'vespers1': vespers(), 'matins': matins(), 'lauds': lauds()}

if __name__ == '__main__':
    H = build()
    for k, v in H.items():
        t = re.sub(r'<[^>]+>', ' ', v); print('=====', k, len(v)); print(re.sub(r'\s+', ' ', t)[:400]); print('...', re.sub(r'\s+', ' ', t)[-900:])

# ---------------- Little Hours and Compline of All Souls ----------------
AD = "adapted"
def psalm_range(n, a=None, b=None):
    la = [l for l in fetch('Latin', f'Psalterium/Psalmorum/Psalm{n}').split('\n') if l.strip()]
    en = [l for l in fetch('English', f'Psalterium/Psalmorum/Psalm{n}').split('\n') if l.strip()]
    if la and la[0].startswith('('):
        return psalm(n)
    def num(l):
        m = re.match(r'^\d+:(\d+)', l); return int(m.group(1)) if m else None
    keep = lambda l: a is None or (num(l) is not None and a <= num(l) <= b)
    L = [l for l in la if keep(l)]; M = [l for l in en if keep(l)]
    title = f'Psalmus {n}' + (f'({a}-{b})' if a else '')
    out = head(title, title)
    if len(L) != len(M): print('WARN verse count', n, a, b, len(L), len(M))
    for x, y in zip(L, M):
        out += pair(f'<ul class="verses"><li>{verse(x)}</li></ul>', f'<ul class="verses"><li>{verse(y)}</li></ul>')
    return out + requiem()

def said_silently(names, note_la, note_en):
    def fmt(t):
        parts = []
        for l in t.split('\n'):
            l = re.sub(r'^v\.\s*', '', l.strip())
            if not l: continue
            l = E(l).replace(' + ', ' ✠ ')
            l = re.sub(r'/:\(?([^:)]*)\)?:/', lambda m: '<span class="rub">(' + m.group(1).strip() + ')</span>', l)
            parts.append(l)
        return ' '.join(parts)
    out = pair(f'<p class="rub">{note_la}</p>', f'<p class="rub">{note_en}</p>')
    for n in names:
        la, en = sec(n, PR)
        out += pair(f'<p>{fmt(la)}</p>', f'<p>{fmt(en)}</p>')
    return out

COLLECT = {
 'Supplices': ("Súpplices, Dómine, pro animábus ómnium famulórum famularúmque tuárum preces effúndimus: ut, quidquid conversatióne contraxérunt humána, clemens indúlgeas, et pœnis eórum finem benígnus impónas.",
               "We thy suppliants, O Lord, pour forth our prayers for the souls of all thy servants and handmaids, that whatsoever they have contracted through human conversation, thou wouldst mercifully pardon, and graciously put an end to their pains.",
               'Per Dominum'),
 'Propitiare': ("Propitiáre, quǽsumus, Dómine, animábus ómnium famulórum famularúmque tuárum, pro quibus majestátem tuam supplíciter exorámus: ut, per hæc piæ deprecatiónis offícia, perveníre mereántur ad réquiem sempitérnam.",
                "Be merciful, we beseech thee, O Lord, unto the souls of all thy servants and handmaids, for whom we humbly entreat thy majesty: that by these offices of loving supplication they may be found worthy to attain unto everlasting rest.",
                'Per Dominum'),
 'Deus veniae': ("Deus, véniæ largítor et humánæ salútis amátor: quǽsumus cleméntiam tuam; ut ánimas ómnium fidélium qui ex hoc sǽculo transiérunt, beáta María semper Vírgine intercedénte cum ómnibus Sanctis tuis, ad perpétuæ beatitúdinis consórtium perveníre concédas.",
                 "O God, the giver of pardon and the lover of man's salvation, we beseech thy clemency, that, blessed Mary ever Virgin and all thy Saints interceding, thou wouldst grant unto the souls of all the faithful who have passed out of this world to attain unto the fellowship of everlasting blessedness.",
                 'Per Christum'),
}
def collect(which):
    la, en, concl = COLLECT[which]
    if concl == 'Per Christum':
        cl, ce = 'Per Christum Dóminum nostrum.', 'Through Christ our Lord.'
    else:
        cl, ce = sec('Per Dominum', PR); cl = cl.split('\n')[0]; ce = ce.split('\n')[0]
    ol, oe = sec('Oremus', PR)
    return (pair(f'<p>{vline(ol)}</p>', f'<p>{vline(oe)}</p>') + pair(f'<p>{E(la)}</p>', f'<p>{E(en)}</p>')
            + pair(f'<p>{vline(cl)}</p>', f'<p>{vline(ce)}</p>') + vr('R. Amen.', 'R. Amen.'))

def little_prayers(which):
    """Pater noster (silently), Et ne nos, A porta inferi..., then the collect"""
    out = rub('All kneel.')
    pl, pe = sec('Pater noster Et', PR)
    out += pair('<p class="rub">Pater noster, secreto usque ad Et ne nos indúcas in tentatiónem:</p>',
                '<p class="rub">Our Father is said silently until And lead us not into temptation:</p>')
    out += vr('\n'.join(pl.split('\n')[1:]), '\n'.join(pe.split('\n')[1:]))
    for n in ('Aportainferi', 'Requiescant'): out += vr(*sec(n, PR))
    dl, de = sec('Dominus', PR)
    out += vr('\n'.join(dl.split('\n')[2:4]), '\n'.join(de.split('\n')[2:4]))
    out += head('Oratio', 'Collect')
    if which == 'Fidelium':
        fl = [l for l in resolve2('Latin', C9, 'Oratio_Fid').split('\n') if l.startswith('v. ')][0][3:]
        ol, oe = sec('Oremus', PR); ql, qe = sec('Qui vivis', PR)
        out += pair(f'<p>{vline(ol)}</p>', f'<p>{vline(oe)}</p>') + pair(f'<p>{E(fl)}</p>', f'<p>{E(FILL["Commune/C9|Oratio"]["text"].split(chr(10))[0])}</p>') + vr(ql, qe)
    else:
        out += collect(which)
    return out

def conclusion():
    rl = REQ[0].replace(' * ', ' '); re_ = REQ[1].replace(' * ', ' ')
    return vr(rl, re_) + vr(*sec('Requiescant', PR))

def hour(psalms, prayer, prime=False, compline=False):
    out = ''
    if compline:
        out += said_silently(['Confiteor', 'Misereatur', 'Indulgentiam'], 'Dicitur:', 'There is said:')
    else:
        names = ['Pater noster', 'Ave Maria'] + (['Credo'] if prime else [])
        out += said_silently(names, 'Dicuntur secreto:', 'The following are said silently:')
    out += rub('Then the psalms are said at once, without antiphons, each ending with Réquiem ætérnam.')
    for p in psalms: out += psalm_range(*p) if isinstance(p, tuple) else psalm_range(p)
    out += little_prayers(prayer)
    if prime:
        out += rub('Here the Martyrology for the morrow is read; then:')
        out += vr('V. In memória ætérna erunt justi.\nR. Ab auditióne mala non timébunt.',
                  'V. The just shall be in everlasting remembrance.\nR. They shall not fear the evil hearing.')
        out += collect('Deus veniae')
    return out + conclusion()

def build():
    return {'vespers1': vespers(), 'matins': matins(), 'lauds': lauds(),
            'prime': hour([87, 27, 31], 'Supplices', prime=True),
            'terce': hour([(37, 1, 11), (37, 12, 23), 55], 'Fidelium'),
            'sext': hour([69, 84, 85], 'Fidelium'),
            'none': hour([(101, 1, 13), (101, 14, 23), (101, 24, 29)], 'Fidelium'),
            'compline': hour([122, 141, 142, 233], 'Propitiare', compline=True)}
