/* ---------- start ---------- */
setLang(store.get('lang','both')); setFs(store.get('fs',19)); setTheme(store.get('theme','auto'));
if(store.get('wake',false)) setWake(true);
document.addEventListener('click',ev=>{if(ev.target.closest('#paschBtn')){PASCH=!PASCH;render(false);}});
fetch('saints/index.json').then(r=>r.json()).then(list=>{
  const seen={}; list.forEach(x=>{const n=seen[x.date]||0; seen[x.date]=n+1; x.id=x.date+(n?'.'+n:'');}); INDEX=list;
  const P=$('#feastPick'); let html='', cm='';
  INDEX.forEach(x=>{const m=x.date.slice(0,2); if(m!==cm){ if(cm) html+='</optgroup>'; html+=`<optgroup label="${MONTHS_EN[+m-1]}">`; cm=m;}
    const tag=x.kind==='commem'?' (com.)':x.kind==='local'?' (local)':'';
    html+=`<option value="${x.id}">${x.date.slice(3)} · ${esc(x.en)}${tag}</option>`;});
  P.innerHTML=html+'</optgroup>';
  P.onchange=()=>{CUR=P.value; render(); window.scrollTo({top:0});};
  const m=location.hash.match(/^#([\d\-.]+)\/(\w+)(\/solo)?/);
  if(m&&INDEX.some(x=>x.id===m[1])){CUR=m[1]; state.hour=m[2]; state.solo=!!m[3];}
  else { const last=store.get('saints.last',null); if(last&&INDEX.some(x=>x.id===last.id)){CUR=last.id;state.hour=last.hour;} else {CUR=feastFor(new Date()); state.hour='lauds';} }
  render(false);
});
</script>
</body>
</html>
