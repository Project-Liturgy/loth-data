import json, re, collections, copy
exec(open('doref.py').read())
S = json.load(open('loth-data/saints_texts.json'))
FILL = json.load(open('loth-data/english_fill.json'))
LOGP = []
# conclusion macros, using the forms already in the saints data
MAC = {}
PRE = {'Per Dominum': 'r. Per Dóminum', 'Per eumdem': 'r. Per eúmdem', 'Qui vivis': 'r. Qui vivis', 'Qui tecum': 'r. Qui tecum'}
for v in S.values():
    x = v['sections'].get('Oratio')
    if not x or not x.get('en'): continue
    la, en = x['la'].split('\n'), x['en'].split('\n')
    for i, a in enumerate(la):
        for k, p in PRE.items():
            if a.startswith(p) and i < len(en) and en[i].startswith('r. ') and k not in MAC: MAC[k] = (a, en[i])
def expand(txt, lang):
    out = []
    for l in (txt or '').split('\n'):
        if l.strip() == '$Deo gratias': out.append('R. Deo grátias.' if lang == 'Latin' else 'R. Thanks be to God.'); continue
        m = re.match(r'^\$(Per Dominum|Per eumdem|Qui vivis|Qui tecum)\b', l)
        if m and m.group(1) in MAC:
            a, b = MAC[m.group(1)]; out.append(a if lang == 'Latin' else b); continue
        out.append(l)
    return '\n'.join(out)

def setsec(key, name, la=None, en=None, src=''):
    x = S[key]['sections'].setdefault(name, {'la': '', 'en': ''})
    if la is not None: x['la'] = la
    if en is not None: x['en'] = en
    x['_src'] = src
    LOGP.append(f'{key[:40]} | {name} | {src}')

# 1) empty Latin sections that were unresolved DO references
for key, v in S.items():
    for name, x in list(v['sections'].items()):
        if name in ('Rank', 'Rule', 'Officium') or (x.get('la') or '').strip(): continue
        la = resolve2('Latin', 'Sancti/' + v['file'], name)
        if not la or la.startswith('&'): continue
        en = resolve2('English', 'Sancti/' + v['file'], name)
        setsec(key, name, expand(la, 'Latin'), expand(en or '', 'English'), 'DO reference resolved (Latin + DO English)')

# 2) Latin present, English missing: DO English through references
SKIP = re.compile(r'(?<=[0-9s])C$|_$|_T$|(?<=\d)o$|^Versum 0|^Initial$|^Oratio mortuorum|^Officium$')
for key, v in S.items():
    for name, x in list(v['sections'].items()):
        if name in ('Rank', 'Rule') or SKIP.search(name): continue
        if (x.get('la') or '').strip() and not (x.get('en') or '').strip():
            en = resolve2('English', 'Sancti/' + v['file'], name)
            if en and not en.startswith('&'):
                setsec(key, name, None, expand(en, 'English'), 'DO English (via its references)')

K = lambda p: [k for k in S if k.startswith(p)][0]
# 3) specific choices
bute_peter = FILL['Sancti/06-29|Versum 0']['text']
setsec(K('08-01'), 'Versum 2', None, bute_peter, "Bute (same versicle as Sts Peter & Paul, Versum 0); DO's modern 'You are Peter' not used")
for p, n in [('10-02', 'Nocturn 1 Versum'), ('10-02', 'Nocturn 2 Versum'), ('10-02', 'Nocturn 3 Versum'), ('10-02', 'Versum 2'),
             ('10-02', 'Versum Tertia'), ('10-02', 'Versum Sexta'), ('10-02', 'Versum 3'), ('10-24', 'Versum 3'), ('09-14', 'Ant Laudes'), ('09-14', 'Ant 1')]:
    x = S[K(p)]['sections'][n]
    if '(Alleluia' in (x.get('en') or ''):
        x['en'] = re.sub(r'\s*\(Alleluia\.?\)', '', x['en']); x['_src'] += '; "(Alleluia.)" (Paschaltide only) removed: not in the Latin'
gk, mk = K('03-12|St. Gregory'), K('11-12|St. Martin I')
for n in ('Lectio7', 'Lectio8', 'Lectio9'):
    en = S[mk]['sections'][n]['en'].replace('Cassarea', 'Caesarea')
    setsec(gk, n, None, en, "English of the same homily (St. Leo) from St. Martin I, Nov 12; scan error 'Cassarea' fixed")
x = S[K('07-23|St. Liborius')]['sections']['Oratio']
if x['en'].startswith('v. '): x['en'] = x['en'][3:]
x['en'] = expand(x['en'], 'English')
setsec(K('10-11'), 'Officium', None, 'The Motherhood of the Blessed Virgin Mary', 'title')
AD = "New English translation in Bute's style (adapted); Bute not checked."
setsec(K('07-14|St. Bonaventure'), 'Lectio6', None,
 "Being summoned by blessed Gregory X to the Council of Lyons, and created Cardinal Bishop of Albano, he did excellent service in the weighty business of the Council, whereby the dissensions of the schism were composed, and the doctrines of the Church vindicated. In the midst of these labours, in the fifty-third year of his age, and in the year of salvation one thousand two hundred and seventy-four, he departed this life, to the exceeding great grief of all, and was honoured with a funeral by the whole Council, the Roman Pontiff himself being present. Sixtus IV numbered him among the Saints, as one renowned for very many and very great miracles. He wrote much, wherein, joining the highest learning with the fervour of piety, he moveth the reader even while he teacheth him: wherefore Sixtus V worthily honoured him with the name of the Seraphic Doctor.", AD)
setsec(K('12-31'), 'Lectio94', None,
 "Sylvester, a Roman, whose father was Rufinus, had lain hid upon Mount Soracte while the persecution raged; and in the thirtieth year of his age he was made a Priest of the holy Roman Church. When Pope Melchiades died, he succeeded in his place, under the Emperor Constantine, who had already given peace to the Church of Christ by public law. Sylvester so encouraged him to defend and spread religion, that the Emperor built many basilicas and endowed them most bountifully. Under this Pontiff was held the first Council of Nicaea, which he confirmed, and wherein Arius was condemned. Famous for the holiness of his life and for his kindness to the poor, he died in peace, and was buried in the cemetery of Priscilla.", AD)
for v in S.values():
    for x in v['sections'].values():
        for L, lang in (('la', 'Latin'), ('en', 'English')):
            if x.get(L) and re.search(r'^\$', x[L], re.M): x[L] = expand(x[L], lang)
json.dump(S, open('saints_texts.json', 'w'), ensure_ascii=False, indent=1)
print('\n'.join(LOGP))
# remaining gaps
rem = [(k[:40], n) for k, v in S.items() for n, x in v['sections'].items()
       if n not in ('Rank', 'Rule') and not SKIP.search(n) and (x.get('la') or '').strip() and not (x.get('en') or '').strip()]
print('REMAINING', rem)
S = json.load(open('saints_texts.json'))
x = S[K('02-12')]['sections']['Versum 0']
if not (x.get('en') or '').strip():
    x['en'] = resolve2('English', 'Sancti/' + S[K('02-12')]['file'], 'Versum 0').replace(':\n', '.\n'); x['_src'] = 'DO English'
    json.dump(S, open('saints_texts.json', 'w'), ensure_ascii=False, indent=1)
print(x)
