
const MONTHS_EN=['January','February','March','April','May','June','July','August','September','October','November','December'];
let INDEX=[], CUR=null; const MCACHE={};
function rec(){return INDEX.find(x=>x.id===CUR)||INDEX[0];}
async function loadDay(){ const e=rec();
  if(e.kind==='local') return {missing:true,en:e.en,local:true};
  const m=e.date.slice(0,2);
  if(!MCACHE[m]) MCACHE[m]=await (await fetch('saints/'+m+'.json')).json();
  return MCACHE[m][e.key]; }
const HOURS = [{"k":"vespers1","en":"I Vespers","la":"Ad I Vesperas","from":0},{"k":"matins","en":"Matins","la":"Ad Matutinum","from":3},{"k":"lauds","en":"Lauds","la":"Ad Laudes","from":5},{"k":"prime","en":"Prime","la":"Ad Primam","from":7},{"k":"terce","en":"Terce","la":"Ad Tertiam","from":9},{"k":"sext","en":"Sext","la":"Ad Sextam","from":12},{"k":"none","en":"None","la":"Ad Nonam","from":15},{"k":"vespers2","en":"II Vespers","la":"Ad II Vesperas","from":17},{"k":"compline","en":"Compline","la":"Ad Completorium","from":20}];
let AV=HOURS;
const $ = s => document.querySelector(s);
const store = {get(k,d){try{const v=localStorage.getItem('rdr.'+k);return v===null?d:JSON.parse(v)}catch(e){return d}},
               set(k,v){try{localStorage.setItem('rdr.'+k,JSON.stringify(v))}catch(e){}}};
