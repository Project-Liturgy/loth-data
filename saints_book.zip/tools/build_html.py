import re
full=open('loth-data/commons.html').read()
head=open('commons_head.html').read()
rest=open('commons_script_rest.js').read()
i=full.find('<script>'); a=full.find('const ALL =')
ante=full[i:a]
head=head.replace('<title>Commune Sanctorum — Common of Apostles</title>','<title>Proprium Sanctorum — Proper of Saints (1954)</title>')
head=head.replace('</style>','''.fromc{font-variant-caps:normal;font-weight:400;font-size:.78em;color:var(--ink-soft);font-style:italic}
.info{color:var(--ink-soft);font-size:.85rem;margin:-4px 0 8px}
.info b{font-weight:500;color:var(--vol)}
</style>''',1)
head=re.sub(r'<select id="commonPick".*?</select>',lambda m:'<select id="feastPick" aria-label="Choose a feast" style="font:inherit;font-size:.9rem;padding:3px 6px;background:var(--parchment);color:var(--ink);border:1px solid var(--line);border-radius:4px;max-width:360px"></select>',head,flags=re.S)
head=head.replace('<div class="day"><span class="en-title" id="enTitle"></span><span class="la-title" id="laTitle"></span><span class="vol" id="vol"></span></div>',
 '<div class="day"><span class="en-title" id="enTitle"></span><span class="la-title" id="laTitle"></span><span class="vol" id="vol"></span></div>\n  <div class="info" id="info"></div>')
head=head.replace('aria-label="Previous day">‹<span class="lbl"> Day</span>','aria-label="Previous feast">‹<span class="lbl"> Feast</span>').replace('aria-label="Next day"><span class="lbl">Day </span>›','aria-label="Next feast"><span class="lbl">Feast </span>›')
head=head.replace('.daynav{visibility:hidden}','')
head=__import__('re').sub(r'<p class="pilotnote">.*?</p>',lambda m:'<p class="pilotnote">Each feast is shown complete: its own texts, with the rest filled in from its Common (marked <i>from the Common</i>). Where a red <span class="rub">N.</span> remains, the saint’s name is said. Rubrics of occurrence and concurrence (which feast is kept on a given day) are not applied here.</p>',head,flags=__import__('re').S)
assert 'feastPick' in head and 'id="info"' in head
top = open('html_top.js').read()
state = open('html_state.js').read()
start = open('html_start.js').read()
mid = rest[958:4849]
events = rest[7697:11738]
events = events.replace("const s=e.target.closest('[data-step]'); if(s){const i=HOURS.findIndex(h=>h.k===state.hour)+Number(s.dataset.step);if(HOURS[i])go(state.date,HOURS[i].k);}",
                        "const s=e.target.closest('[data-step]'); if(s){const i=AV.findIndex(h=>h.k===state.hour)+Number(s.dataset.step);if(AV[i]){state.hour=AV[i].k;render();window.scrollTo({top:0});}}")
events = events.replace("function stepDay(n){go(addDays(state.date,n),state.hour)}","function stepDay(n){stepFeast(n)}")
events = events.replace("const i=HOURS.findIndex(h=>h.k===state.hour);\n  if(e.key==='ArrowRight'&&HOURS[i+1])go(state.date,HOURS[i+1].k); if(e.key==='ArrowLeft'&&HOURS[i-1])go(state.date,HOURS[i-1].k);",
                        "const i=AV.findIndex(h=>h.k===state.hour);\n  if(e.key==='ArrowRight'&&AV[i+1]){state.hour=AV[i+1].k;render()} if(e.key==='ArrowLeft'&&AV[i-1]){state.hour=AV[i-1].k;render()}")
HC="window.addEventListener('hashchange',()=>{const m=location.hash.match(/^#([\\d\\-.]+)\\/(\\w+)(\\/solo)?/);if(m&&INDEX.some(x=>x.id===m[1])){CUR=m[1];state.hour=m[2];state.solo=!!m[3];render(false)}});\n"
events = re.sub(r"window\.addEventListener\('hashchange'.*?\n", lambda m: HC, events, count=1)
events = events.replace("$('#ribbons').addEventListener('click',e=>{const b=e.target.closest('.rib');if(b)go(state.date,b.dataset.h)});","$('#ribbons').addEventListener('click',e=>{const b=e.target.closest('.rib');if(b){state.hour=b.dataset.h;render();window.scrollTo({top:0});}});")
for needle in ["state.hour=b.dataset.h;render()","AV.findIndex(h=>h.k===state.hour)+Number","function stepDay(n){stepFeast(n)}","AV[i+1].k;render()","INDEX.some(x=>x.id===m[1])"]:
    assert needle in events, needle
out=head+ante+top+mid+state+events+start
open('out/saints.html','w').write(out)
print(len(out))
