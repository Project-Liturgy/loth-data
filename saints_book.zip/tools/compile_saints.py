"""Compile the Proper of Saints (1954) into per-month JSON for saints.html.
Inputs: loth-data/saints_texts.json, saints_1954.csv, commons_all.json (from commons.html),
        do_names.json (DO [Name] sections), versum0_names.json.
"""
import json, re, csv, html, collections, os, sys

D = 'loth-data/'
S = json.load(open(D + 'saints_texts.json'))
ROWS = {r['date'] + '|' + r['feast_english']: r for r in csv.DictReader(open(D + 'saints_1954.csv', encoding='utf-8-sig'))}
LOCAL = [r for k, r in ROWS.items() if k not in S]
ALL = json.load(open('commons_all.json'))
NAMES = json.load(open('do_names.json'))
V0 = json.load(open(D + 'versum0_names.json'))
NAMEFORMS = json.load(open('/home/claude/latin_name_forms.json'))
LOG = collections.defaultdict(list)
FILL = json.load(open(D + 'english_fill.json'))
V0_FILL_FROM = {'01-25': 'Commune/C1|Versum 0', '03-25': 'Psalterium/Special/Major Special|Adv Versum 0'}
def apply_fills(v):
    for k, f in FILL.items():
        src, sec = k.split('|', 1)
        if src == 'Sancti/' + v['file'] and sec in v['sections'] and not (v['sections'][sec].get('en') or '').strip():
            v['sections'][sec] = dict(v['sections'][sec], en=f['text'])
    d = v['date']
    if d in V0_FILL_FROM and 'Versum 0' in v['sections'] and not (v['sections']['Versum 0'].get('en') or '').strip():
        v['sections']['Versum 0'] = dict(v['sections']['Versum 0'], en=FILL[V0_FILL_FROM[d]]['text'])


# Latin vocative for "Ora pro nobis, beate N." (DO [Name] used when it is in this case)
V0_LA = {'01-21': 'Agnes', '01-22': 'Vincénti', '01-23': 'Raymúnde', '02-05': 'Agatha', '04-05': 'Vincénti',
         '04-29': 'Petre', '04-30': 'Catharína', '05-05': 'Pie', '05-10': 'Antoníne', '08-10': 'Lauréntí',
         '08-28': 'Augustíne', '08-29': 'Joánnes Baptísta', '08-30': 'Rosa', '10-04': 'Pater Francísce',
         '10-08': 'Birgítta', '10-15': 'Terésia', '11-11': 'Martíne', '11-15': 'Albérte', '11-22': 'Cæcília',
         '11-23': 'Clemens', '12-06': 'Nicoláe', '12-13': 'Lúcia', '12-26': 'Stéphane'}
V0_EN_EXTRA = {'01-23': 'Raymund'}

LAB = {'Antiphonæ': 'Antiphons', 'Hymnus': 'Hymn', 'Versus': 'Versicle', 'Ad Magnificat': 'At the Magnificat',
       'Oratio': 'Collect', 'Invitatorium': 'Invitatory', 'Capitulum': 'Chapter', 'Ad Benedictus': 'At the Benedictus',
       'Lectio brevis': 'Short Lesson', 'Responsorium breve': 'Short Responsory',
       'In I Nocturno': 'Nocturn I', 'In II Nocturno': 'Nocturn II', 'In III Nocturno': 'Nocturn III'}
ROM = ['', 'i', 'ii', 'iii', 'iv', 'v', 'vi', 'vii', 'viii', 'ix']
for n in range(1, 10):
    LAB[f'Lectio {ROM[n]}'] = f'Lesson {n}'
    LAB[f'Responsorium {ROM[n]}'] = f'Responsory {n}'

# ---------------- rendering DO-format text ----------------
def esc(s): return html.escape(s, quote=False)

def line_html(l, kind):
    l = re.sub(r'\{:[^}]*:\}', '', l).rstrip()
    if not l.strip() or l.strip() == '_': return None
    if l.startswith('&teDeum'): return '<span class="rub">Te Deum.</span>'
    if l.startswith('$') or l.startswith('&'): return '<span class="rub">' + esc(l[1:]) + '</span>'
    if l.startswith('!'): return '<span class="rub">' + esc(l[1:].strip()) + '</span>'
    ps = ''
    m = re.search(r';;\s*([\d;,\s]+)$', l)
    if m:
        ps = ' <span class="rub">Ps. ' + m.group(1).strip().replace(';', ', ') + '</span>'
        l = l[:m.start()]
    l = re.sub(r'^v\.\s*', '', l)
    l = re.sub(r'^r\.\s*', '', l)
    l = re.sub(r'^R\.br\.\s*', '℟. br. ', l)
    l = re.sub(r'^R\.\s*', '℟. ', l)
    l = re.sub(r'^V\.\s*', '℣. ', l)
    if kind == 'resp': l = re.sub(r'^\*\s*', '', l)
    t = esc(l)
    if kind == 'lesson':
        t = re.sub(r'^(\d+)\s', r'<span class="rub">\1</span> ', t)
    t = t.replace('N.', '<span class="rub">N.</span>') if re.search(r'\bN\.', l) else t
    return t + ps

def lines(txt, kind):
    return [x for x in (line_html(l, kind) for l in (txt or '').split('\n')) if x is not None]

def stanzas(txt):
    txt = re.sub(r'\{:[^}]*:\}', '', txt or '')
    out, cur = [], []
    for l in txt.split('\n'):
        l = l.strip()
        if l == '_':
            if cur: out.append(cur); cur = []
            continue
        if not l: continue
        cur.append(esc(re.sub(r'^v\.\s*', '', l)))
    if cur: out.append(cur)
    return ['<br>'.join(s) for s in out]

def pairs(la_items, en_items, cls='p'):
    """aligned pairs if counts match, else one pair holding all."""
    tag = (lambda x: f'<p class="hymn">{x}</p>') if cls == 'hymn' else (lambda x: f'<p>{x}</p>')
    if len(la_items) == len(en_items) or not en_items:
        en_items = en_items or [''] * len(la_items)
        return ''.join(f'<div class="pair"><div class="la">{tag(a)}</div><div class="en">{tag(b) if b else ""}</div></div>\n'
                       for a, b in zip(la_items, en_items))
    return (f'<div class="pair"><div class="la">{"".join(tag(a) for a in la_items)}</div>'
            f'<div class="en">{"".join(tag(b) for b in en_items)}</div></div>\n')

def head(la, extra=False):
    en = LAB.get(la, la)
    la2 = la + (' <span class="fromc">· ex Commúni</span>' if extra else '')
    en2 = en + (' <span class="fromc">· from the Common</span>' if extra else '')
    return f'<div class="pair"><div class="la"><h3>{la2}</h3></div><div class="en"><h3>{en2}</h3></div></div>\n'

def rub(t): return f'<p class="rub" style="text-align:center;margin:10px 0">{esc(t)}</p>\n'

def render(label, sec, kind='p'):
    la, en = sec.get('la') or '', sec.get('en') or ''
    src = sec.get('_from')
    if kind == 'hymn':
        body = pairs(stanzas(la), stanzas(en), 'hymn')
    else:
        body = pairs(lines(la, kind), lines(en, kind))
    h = head(label)
    if src:
        h = h.replace('</h3></div><div class="en"><h3>', '</h3></div><div class="en"><h3>', 1)
        h = re.sub(r'(<div class="en"><h3>)([^<]*)(</h3>)', lambda m: m.group(1) + m.group(2) + f' <span class="fromc">· as on {esc(src)}</span>' + m.group(3), h, count=1)
    return h + body

# ---------------- common blocks ----------------
def split_blocks(h):
    idx = [m.start() for m in re.finditer(r'<div class="pair[^"]*"><div class="la"><h3>', h)]
    out = []
    if not idx: return [('', h)]
    if idx[0] > 0: out.append(('', h[:idx[0]]))
    for a, b in zip(idx, idx[1:] + [len(h)]):
        lab = re.match(r'<div class="pair[^"]*"><div class="la"><h3>([^<]*)</h3>', h[a:]).group(1)
        out.append((lab, h[a:b]))
    return out

CB = {k: {h: collections.OrderedDict(split_blocks(v)) for h, v in c['hours'].items()} for k, c in ALL.items()}

def from_common(block):
    """mark a common block's header as from the Common"""
    return re.sub(r'<div class="la"><h3>([^<]*)</h3></div><div class="en"><h3>([^<]*)</h3>',
                  lambda m: f'<div class="la"><h3>{m.group(1)} <span class="fromc">· ex Commúni</span></h3></div>'
                            f'<div class="en"><h3>{m.group(2)} <span class="fromc">· from the Common</span></h3>', block, count=1)

GEN_CTX = {'beáti', 'beátæ', 'nostri', 'patris', 'mártyris', 'pontíficum', 'tuórum', 'beatórum', 'tuárum', 'sancti', 'sanctæ'}
ACC_CTX = {'beátum', 'beátam', 'sanctum'}
VOC_CTX = {'beáte', 'beáta'}
ABL_CTX = {'beáto', 'beáta̱'}
def name_case(n):
    w = n.split()[-1].lower()
    if re.search(r'(um|am|em)$', w): return 'acc'
    if re.search(r'(i|æ|is|ónis|óris)$', w): return 'gen'
    return 'voc'
N_SPAN = '<span class="rub">N.</span>'
def fill_la(text, name, who):
    for a, b in NAMEFORMS.get(who, {}).get('phrase', {}).items():
        if a in text:
            text = text.replace(a, b); LOG['plural phrase applied'].append(f'{who}: {b}')
    tab0 = NAMEFORMS.get(who, {})
    if (not name and not any(k in tab0 for k in ('gen', 'acc', 'voc', 'abl'))) or N_SPAN not in text: return text
    name = name or ''
    pair = ' et ' in name
    t = text.replace(N_SPAN + ' et ' + N_SPAN, '\x00') if pair else text
    if pair: t = t.replace('\x00', esc(name))
    def rep(m):
        prev = re.sub(r'<[^>]+>', '', m.group(1)).lower()
        need = 'gen' if prev in GEN_CTX else 'acc' if prev in ACC_CTX else 'voc' if prev in VOC_CTX else 'abl' if prev in ABL_CTX else '?'
        tab = NAMEFORMS.get(who, {})
        if need in tab:
            return m.group(1) + ' ' + esc(tab[need])
        if name and need == name_case(name):
            return m.group(1) + ' ' + esc(name)
        LOG['Latin N. left (name case does not fit)'].append(f'{who}: "{prev} N." needs {need}, DO name "{name}"')
        return m.group(0)
    return re.sub(r'(\S+)\s+' + re.escape(N_SPAN), rep, t)
def fill_name(block, la_name, en_name, who=''):
    en_name = en_name or NAMEFORMS.get(who, {}).get('en')
    def one(m):
        a, b = m.group(2), m.group(4)
        a = fill_la(a, la_name, who)
        if en_name:
            b = b.replace(N_SPAN + ' and ' + N_SPAN, esc(en_name)).replace(N_SPAN + ' et ' + N_SPAN, esc(en_name)).replace(N_SPAN, esc(en_name))
        return m.group(1) + a + m.group(3) + b + m.group(5)
    return re.sub(r'(<div class="la">)(.*?)(</div><div class="en">)(.*?)(</div></div>)', one, block, flags=re.S)

BYFILE = {v['file']: (k, v) for k, v in S.items()}
NINTH = {}
for _k, _v in S.items():
    if ROWS[_k]['kept_in_1954'] != 'Commemoration': continue
    for _lk in ('Lectio94', 'Lectio93', 'Lectio4'):
        if _lk in _v['sections'] and (_v['sections'][_lk].get('la') or '').strip():
            for _k2, _v2 in S.items():
                if _v2['date'] == _v['date'] and ROWS[_k2]['kept_in_1954'] == 'Office':
                    NINTH.setdefault(f"{_v['date']} {ROWS[_k2]['feast_english']}", (_v['sections'][_lk], ROWS[_k]['feast_english']))
            break
def inherited(v, depth=0):
    """sections inherited through 'ex/vide Sancti/..' rules, with their source title"""
    rule = (v['sections'].get('Rule') or {}).get('la') or ''
    m = re.search(r'(ex|vide) Sancti/([0-9a-z\-]+)', rule)
    if not m or depth > 3 or m.group(2) not in BYFILE: return {}, None
    mode, (bk, bv) = m.group(1), BYFILE[m.group(2)]
    apply_fills(bv)
    base, _ = inherited(bv, depth + 1)
    base = dict(base)
    for k, x in bv['sections'].items():
        if k in ('Rank', 'Rule', 'Officium'): continue
        base[k] = dict(x, _from=ROWS[bk]['feast_english'])
    if mode == 'vide':
        base = {k: x for k, x in base.items() if not re.match(r'Lectio\d', k)}
    return base, ROWS[bk]['feast_english']

# ---------------- templates ----------------
SLOTS = {
 'vespers1': [('Antiphonæ', 'Ant Vespera', 'p'), ('Capitulum', 'Capitulum Vespera', 'p'), ('Hymnus', 'Hymnus Vespera', 'hymn'),
              ('Versus', 'Versum 1', 'p'), ('Ad Magnificat', 'Ant 1', 'p'), ('Oratio', 'Oratio', 'p')],
 'lauds':    [('Antiphonæ', 'Ant Laudes', 'p'), ('Capitulum', 'Capitulum Laudes', 'p'), ('Hymnus', 'Hymnus Laudes', 'hymn'),
              ('Versus', 'Versum 2', 'p'), ('Ad Benedictus', 'Ant 2', 'p'), ('Oratio', 'Oratio', 'p')],
 'prime':    [('Lectio brevis', 'Lectio Prima', 'p')],
 'terce':    [('Capitulum', 'Capitulum Tertia', 'p'), ('Responsorium breve', 'Responsory Breve Tertia', 'resp'),
              ('Versus', 'Versum Tertia', 'p'), ('Oratio', 'Oratio', 'p')],
 'sext':     [('Capitulum', 'Capitulum Sexta', 'p'), ('Responsorium breve', 'Responsory Breve Sexta', 'resp'),
              ('Versus', 'Versum Sexta', 'p'), ('Oratio', 'Oratio', 'p')],
 'none':     [('Capitulum', 'Capitulum Nona', 'p'), ('Responsorium breve', 'Responsory Breve Nona', 'resp'),
              ('Versus', 'Versum Nona', 'p'), ('Oratio', 'Oratio', 'p')],
 'vespers2': [('Antiphonæ', 'Ant Vespera 3', 'p'), ('Capitulum', 'Capitulum Vespera 3', 'p'), ('Hymnus', 'Hymnus Vespera 3', 'hymn'),
              ('Versus', 'Versum 3', 'p'), ('Ad Magnificat', 'Ant 3', 'p'), ('Oratio', 'Oratio', 'p')],
}

def nocturns(sec, S):
    """split Ant Matutinum into three nocturns: (la lines, en lines) each"""
    la = [l for l in (sec.get('la') or '').split('\n') if l.strip()]
    en = [l for l in (sec.get('en') or '').split('\n') if l.strip()]
    def groups(L):
        if not any(l.startswith('V.') for l in L):
            A = [l for l in L]
            n = len(A); k = [3, 3, n - 6] if n >= 7 else [n]
            out, i = [], 0
            for s in k: out.append(A[i:i + s]); i += s
            return out
        g, cur, seenV = [], [], False
        for l in L:
            if l.startswith('R.') and seenV:
                cur.append(l); g.append(cur); cur = []; seenV = False; continue
            if l.startswith('V.'): seenV = True
            cur.append(l)
        if cur: g.append(cur)
        return g
    gl, ge = groups(la), groups(en)
    if len(ge) != len(gl): ge = [None] * len(gl)
    return list(zip(gl, ge))

def common_versicle(ck, n):
    """versicle pairs (html) from the Common's nocturn n block"""
    blk = CB.get(ck, {}).get('matins', {}).get(['', 'In I Nocturno', 'In II Nocturno', 'In III Nocturno'][n], '') if ck else ''
    ps = re.findall(r'<div class="pair[^"]*"><div class="la">(?:(?!</div>).)*?℣\.(?:(?!</div>).)*</div><div class="en">(?:(?!</div>).)*</div></div>\n?|<div class="pair[^"]*"><div class="la">(?:(?!</div>).)*?℟\.(?:(?!</div>).)*</div><div class="en">(?:(?!</div>).)*</div></div>\n?', blk)
    return ''.join(ps)

def render_matins(S, ck, cname, office_kind, rank, who=''):
    sec = S
    cb = CB.get(ck, {}).get('matins', {}) if ck else {}
    out = []
    def slot(label, key, kind='p'):
        if key in sec and (sec[key].get('la') or '').strip():
            out.append(render(label, sec[key], kind)); return True
        if label in cb:
            out.append(fill_name(from_common(cb[label]), *cname, who)); return True
        return False
    simplex = office_kind == 'simplex'
    slot('Invitatorium', 'Invit'); slot('Hymnus', 'Hymnus Matutinum', 'hymn')
    if simplex:
        out.append(rub('Psalms of the occurring feria. Lessons i and ii from the occurring Scripture.'))
        for k in ('Lectio93', 'Lectio94', 'Lectio3', 'Lectio4'):
            if k in sec and (sec[k].get('la') or '').strip():
                out.append(render('Lectio iii', sec[k], 'lesson')); break
        return ''.join(out)
    noct = nocturns(sec['Ant Matutinum'], S) if 'Ant Matutinum' in sec else None
    for n in (1, 2, 3):
        label = ['', 'In I Nocturno', 'In II Nocturno', 'In III Nocturno'][n]
        if noct and len(noct) >= n:
            la_l, en_l = noct[n - 1]
            vk = f'Nocturn {n} Versum'
            if vk in sec:  # proper nocturn versicle replaces
                la_l = [l for l in la_l if not l.startswith(('V.', 'R.'))] + (sec[vk]['la'] or '').split('\n')
                if en_l is not None:
                    en_l = [l for l in en_l if not l.startswith(('V.', 'R.'))] + (sec[vk].get('en') or '').split('\n')
            out.append(render(label, {'la': '\n'.join(la_l), 'en': '\n'.join(en_l) if en_l else ''}))
            if not any(l.startswith('V.') for l in la_l):
                cv = common_versicle(ck, n)
                if cv: out.append(cv)
                else: LOG['nocturn versicle missing'].append(f'{who} nocturn {n}')
        elif label in cb:
            out.append(fill_name(from_common(cb[label]), *cname, who))
        lessons = range(3 * n - 2, 3 * n + 1)
        if n == 1 and not any(f'Lectio{i}' in sec for i in lessons):
            if 'Lectio i' in cb:
                out.append(rub('Lessons of the first Nocturn: from the occurring Scripture; when there is none, from the Common, as follows.'))
            else:
                out.append(rub('Lessons i–iii of the first Nocturn, with their responsories, are from the occurring Scripture.'))
        for i in lessons:
            key = f'Lectio{i}'
            if i == 3 and key not in sec and 'Lectio93' in sec and 'Lectio2' in sec: key = 'Lectio93'
            if i == 9 and key not in sec and NINTH.get(who):
                nk, nl = NINTH[who]
                out.append(rub(f'The ninth lesson is of the commemoration of {nl}:'))
                out.append(render('Lectio ix', nk, 'lesson')); continue
            slot(f'Lectio {ROM[i]}', key, 'lesson')
            if i < 9: slot(f'Responsorium {ROM[i]}', f'Responsory{i}', 'resp')
    if 'Lectio94' in sec and (sec['Lectio94'].get('la') or '').strip():
        out.append(rub('When this feast is only commemorated, this lesson is read as the ninth:'))
        out.append(render('Lectio ix', sec['Lectio94'], 'lesson'))
    out.append(rub('Te Deum.'))
    return ''.join(out)

def v0_block(date, sec):
    if 'Versum 0' not in sec: return ''
    x = dict(sec['Versum 0'])
    la = x.get('la') or ''
    if 'N.' in la:
        if date not in V0_LA and x.get('_from'):
            src = [r['date'] for r in ROWS.values() if r['feast_english'] == x['_from']]
            if src: date = src[0]
        nm = V0_LA.get(date)
        en_nm = (V0.get(date) or {}).get('en') or V0_EN_EXTRA.get(date)
        if not nm or not en_nm:
            LOG['versum0 name missing'].append(date); return ''
        la = la.replace('N..', nm + '.').replace('N.', nm)
        x = {'la': la, 'en': f'V. Blessed {en_nm}, pray for us.\nR. That we may be made worthy of the promises of Christ.'}
    if not (x.get('en') or '').strip():
        if date not in LOG['versum0 no English']: LOG['versum0 no English'].append(date)
    return rub('When this saint is only commemorated, this versicle is used:') + pairs(lines(x['la'], 'p'), lines(x.get('en') or '', 'p'))

def compile_one(key, v, r, ck_override=None):
    date = v['date']
    apply_fills(v)
    own = {k: x for k, x in v['sections'].items() if k not in ('Rank', 'Rule', 'Officium')}
    base, base_title = inherited(v)
    sec = dict(base); sec.update(own)
    dc = r['do_common'] or ''
    ck = None
    m = re.search(r'(C\d+[a-z]*(?:-\d)?)', dc)
    if m: ck = m.group(1)
    if ck and ck not in ALL:
        fb = re.sub(r'-\d$', '', ck)
        LOG['common fallback'].append(f'{date} {ck}->{fb if fb in ALL else None}')
        ck = fb if fb in ALL else None
    if not ck and base_title:
        br = [rr for rr in ROWS.values() if rr['feast_english'] == base_title]
        mm = re.search(r'(C\d+[a-z]*(?:-\d)?)', br[0]['do_common'] if br else '')
        if mm and mm.group(1) in ALL: ck = mm.group(1)
    if ck_override: ck = ck_override
    nm = NAMES.get(v['file'], {})
    la_name = next((x for x in (nm.get('la') or []) if '=' not in x), None)
    en_name = next((x for x in (nm.get('en') or []) if '=' not in x), None)
    if date == '10-08' and 'Bridget' in key: la_name = None
    cname = (la_name, en_name); who = f'{date} {r["feast_english"]}'
    rank = r['rank']; kept = r['kept_in_1954']
    simplex = rank.startswith('simplex') or rank.startswith('vigil')
    kind = 'commem' if kept == 'Commemoration' else ('simplex' if rank.startswith('simplex') else 'office')
    hours = {}
    cb_all = CB.get(ck, {}) if ck else {}
    used_common_N = False
    for h, slots in SLOTS.items():
        if kind == 'commem' and h not in ('vespers1', 'lauds', 'vespers2'): continue
        if kind == 'commem' and h == 'vespers2' and rank.startswith('simplex'): continue
        if kind == 'simplex' and h == 'vespers2': continue
        cb = cb_all.get(h, {})
        out = []
        if kind == 'commem':
            out.append(rub('Commemoration:'))
            slots = [s for s in slots if s[0] in ('Ad Magnificat', 'Ad Benedictus', 'Versus', 'Oratio')]
            slots = sorted(slots, key=lambda s: ['Ad Magnificat', 'Ad Benedictus', 'Versus', 'Oratio'].index(s[0]))
        if h == 'vespers2' and kind != 'commem':
            out.append(rub('All as at First Vespers, except:'))
        for label, k, rk in slots:
            alt = None
            if h == 'vespers2' and kind != 'commem' and k not in sec and label not in cb:
                continue  # II Vespers shows only what differs
            if k in sec and (sec[k].get('la') or '').strip():
                out.append(render(label, sec[k], rk))
                if label == 'Oratio': out.append(v0_block(date, sec))
            else:
                blk = cb.get(label)
                if label == 'Capitulum' and h in ('vespers1', 'terce') and 'Capitulum Laudes' in sec:
                    out.append(rub('Chapter as at Lauds.')); continue
                if blk:
                    if '<span class="rub">N.</span>' in blk: used_common_N = True
                    out.append(fill_name(from_common(blk), *cname, who))
                    if label == 'Oratio': out.append(v0_block(date, sec))
                elif label == 'Capitulum' and h == 'vespers1' and cb.get('', '').find('Chapter as at Lauds') >= 0:
                    out.append(rub('Chapter as at Lauds.'))
        hours[h] = ''.join(out)
    if kind == 'commem':
        for k in ('Lectio94', 'Lectio93'):
            if k in sec and (sec[k].get('la') or '').strip():
                hours['matins'] = rub('When commemorated at Matins, this lesson is read as the ninth (or third):') + render('Lectio ix', sec[k], 'lesson')
                break
    else:
        hours['matins'] = render_matins(sec, ck, cname, kind, rank, who)
    if used_common_N and not (la_name and en_name):
        LOG['collect N. unfilled'].append(f'{date} {v["feast"]}')
    if date == '11-02' and 'All Souls' in key:
        import importlib.util, sys
        spec = importlib.util.spec_from_file_location('od', '/home/claude/od.py'); od = importlib.util.module_from_spec(spec); spec.loader.exec_module(od)
        hours = od.build()
    hours = {h: (fill_name(x, *cname, who) if N_SPAN in x else x) for h, x in hours.items()}
    order = ['vespers1', 'matins', 'lauds', 'prime', 'terce', 'sext', 'none', 'vespers2', 'compline']
    hours = {h: hours[h] for h in order if h in hours and hours[h].strip()}
    missing_en = [k for k, x in v['sections'].items() if k not in ('Rank', 'Rule', 'Versum 0') and (x.get('la') or '').strip() and not (x.get('en') or '').strip()]
    if missing_en: LOG['sections without English'].append(f'{date} {v["feast"]}: {", ".join(missing_en)}')
    title_la = (v['sections'].get('Officium') or {}).get('la') or r['feast_latin']
    return {'key': key, 'date': date, 'en': r['feast_english'], 'la': title_la, 'rank': rank, 'kept': kept,
            'common': ck, 'common_name': (ALL[ck]['en'].split(' — ')[0] if ck else 'Proper'), 'pasch': r['do_common_paschaltide'],
            'commem': r['commemorations_1954'], 'kind': kind, 'hours': hours}

def main():
    os.makedirs('out/saints', exist_ok=True)
    months = collections.defaultdict(dict); index = []
    for key, v in S.items():
        rec = compile_one(key, v, ROWS[key])
        r = ROWS[key]
        if r['do_common_paschaltide'] and rec['common']:
            pk = rec['common'] + 'p' if rec['common'] + 'p' in ALL else r['do_common_paschaltide']
            if pk in ALL:
                rp = compile_one(key, json.loads(json.dumps(v)), r, ck_override=pk)
                rec['hours_pasch'] = rp['hours']; rec['common_pasch'] = ALL[pk]['en'].split(' — ')[0]
            else:
                LOG['paschal common missing'].append(f'{key} {pk}')
        months[v['date'][:2]][key] = rec
        index.append({k: rec[k] for k in ('key', 'date', 'en', 'la', 'rank', 'kept', 'common_name', 'kind')} | {'hours': list(rec['hours'])})
    for r in LOCAL:
        index.append({'key': r['date'] + '|' + r['feast_english'], 'date': r['date'], 'en': r['feast_english'], 'la': r['feast_latin'],
                      'rank': r['rank'], 'kept': 'LOCAL', 'common_name': '', 'kind': 'local', 'hours': []})
    index.sort(key=lambda x: (x['date'], x['kind'] == 'commem', x['kind'] == 'local'))
    for mth, d in months.items():
        json.dump(d, open(f'out/saints/{mth}.json', 'w'), ensure_ascii=False, separators=(',', ':'))
    json.dump(index, open('out/saints/index.json', 'w'), ensure_ascii=False, separators=(',', ':'))
    for k, v in LOG.items():
        print(f'== {k} ({len(v)})'); [print('  ', x) for x in v]

if __name__ == '__main__':
    main()
